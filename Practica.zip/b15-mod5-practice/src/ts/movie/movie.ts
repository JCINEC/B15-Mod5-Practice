import { MovieLayoutMode } from "../models/movie-layout-mode.enum";
import { MovieListData } from "../models/movie-list-data.interface";
import { MovieListType } from "../models/movie-type.enum";
import {
  fetchMovieListData,
  fetchSearchMovieListData,
  getDetailsData,
} from "../api/api";
import { MovieDetail } from "../models/movie-detail.interface";
import { addEventListenerMovieCard } from "../event/event";
import { Actor } from "../models/actor.interface";

let currentListType = MovieListType.NowPlaying;
let currentListMode = MovieLayoutMode.Grid;
let currentMovieListData: MovieListData[];
let total_pages: number = 0;
let currPage: number = 1;
export let currSearch: string = "";
export let currSearchPage: number = 1;

export async function updateMoviesContent(page: number = currPage) {
  const data = await fetchMovieListData(currentListType, page);
  currentMovieListData = data.movies;
  currPage = page;
  total_pages = data.total_pages;
  showMovieList(currentMovieListData, currPage, total_pages);
}

export async function updateMovieDetailsContent(id: string) {
  const data = await getDetailsData(id);
  createDetails(data);
  // showMovieList(currentMovieListData);
}

export async function searchMovie(text: string, page: number = 1) {
  const data = await fetchSearchMovieListData(text, currPage);
  currSearch = text;
  currentMovieListData = data.movies;
  total_pages = data.total_pages;
  currSearchPage = page;
  showMovieList(currentMovieListData, currPage, total_pages);
}

export async function setCurrentListType(newValue: MovieListType) {
  currentListType = newValue;
  // fetch de nuevo listado de películas
  currSearch = "";
  const data = await fetchMovieListData(currentListType);
  currentMovieListData = data.movies;
  total_pages = data.total_pages;
  currPage = 1;
  showMovieList(currentMovieListData, currPage, total_pages);
}

export function setCurrentListMode(newValue: MovieLayoutMode) {
  console.log("Buenas!", newValue);
  currentListMode = newValue;
  showMovieList(currentMovieListData, currPage, total_pages);
}

export function showMovieList(movieListData: MovieListData[], page, pages) {
  console.log("showMovies", movieListData);
  const movieListElement = createMovies(movieListData);
  const app = document.querySelector("#app");
  if (app !== null) {
    app.innerHTML = "";
    app.appendChild(movieListElement);
    editPagesNav(page, pages);
  }
}

function createElem(elem: string, className: string): HTMLElement {
  const e = document.createElement(elem);
  e.className = className;
  return e;
}

function createBackdrop(
  elem: string,
  className: string,
  url: string
): HTMLElement {
  const e = createElem(elem, className);
  console.log(url);
  e.setAttribute("style", `background-image: url(${url});`);
  return e;
}

function createDetailRatingAndYear(
  elem: string,
  className: string,
  rating: number,
  year: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = "Valoración: " + rating + " | Año: " + year;
  return e;
}

function createSynopsis(
  elem: string,
  className: string,
  description: string
): HTMLElement {
  const e = createElem(elem, className);
  e.innerHTML = "<h6>Sinopsis:</h6>" + description;
  return e;
}

function createActorCard(actor: Actor): HTMLElement {
  const card = createElem("div", "card");
  const poster = createPoster("poster", actor.path);
  card.appendChild(poster);
  const name = createElem("span", "");
  name.textContent = "Nombre:" + actor.name;
  card.appendChild(name);
  const character = createElem("span", "");
  character.textContent = "Personaje: " + actor.character;
  card.appendChild(character);
  return card;
}

function actors(actors: Actor[]): HTMLElement {
  const arr: HTMLElement[] = actors.map(createActorCard);
  const row = createElem("div","row d-flex justify-content-between");
  arr.forEach((actor)=> row.appendChild(actor));
  return row;
}

function createDetails(data: MovieDetail) {
  const app = document.querySelector("#app");
  if (app !== null) {
    app.innerHTML = "";

    const header = createArticle(
      "article",
      "content list col-12 col-sm-6 col-md-4 col-lg-3 mb-4",
      data.id
    );

    const d1 = createElem("div", "card-list");
    const d2 = createElem("div", "row g-0");
    d1.appendChild(d2);
    const d3 = createElem("div", "col-12");
    d2.appendChild(d3);
    const poster = createPoster("poster", data.poster);
    d3.appendChild(poster);
    const d4 = createElem("div", "col-12");
    d2.appendChild(d4);
    const d5 = createElem("div", "car-body");
    const title = createTitle("h5", "card-title my-3 mx-3", data.title);
    d5.appendChild(title);
    const genres = createElem("div","");
    let i = 0;
    genres.textContent = data.genres[i];
    i++;
    while(i < data.genres.length) {
      genres.textContent +=  ", " + data.genres[i];
      i++;
    }
    d5.appendChild(genres);
    const duration = createElem("div","px50");
    duration.textContent = data.duration + " m";
    d5.appendChild(duration);
    const ratingAndYear = createDetailRatingAndYear(
      "span",
      "my-3 mx-3",
      data.rating,
      data.year
    );
    d5.appendChild(ratingAndYear);
    const description = createSynopsis(
      "p",
      "card-text my-3 mx-3",
      data.synopsis
    );
    d5.appendChild(description);
    d4.appendChild(d5);
    const dirp = createPoster("poster", data.director_path);
    console.log("Director:" + data.director_path);
    const dirn = createElem("span", data.director);
    d5.appendChild(dirp);
    d5.appendChild(dirn);
    const d6 = actors(data.actors);
    d5.appendChild(d6);
    header.appendChild(d1);
    const details = createBackdrop("div", "row backdrop", data.backdrop);
    const opacity = createElem("div", "opacity");
    details.appendChild(opacity);
    opacity.appendChild(header);
    app.appendChild(details);
  }
}

function createArticle(
  elem: string,
  className: string,
  id: number
): HTMLElement {
  const e = createElem(elem, className);
  e.id = `${id}`;
  addEventListenerMovieCard(e);
  return e;
}

function createPoster(className: string, url: string): HTMLImageElement {
  const e = document.createElement("img");
  e.className = className;
  e.src = url;
  return e;
}

function createTitle(
  elem: string,
  className: string,
  title: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = title;
  return e;
}

function createRatingAndYear(
  elem: string,
  className: string,
  rating: number,
  year: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = "Rating: " + rating + " | " + year;
  return e;
}

function createDescription(
  elem: string,
  className: string,
  description: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = description;
  return e;
}

function createFilm(data: MovieListData): HTMLElement {
  const film =
    currentListMode === MovieLayoutMode.Grid
      ? createArticle(
          "article",
          "col-12 col-sm-6 col-md-4 col-lg-3 mb-4",
          data.id
        )
      : createArticle(
          "article",
          "list col-12 col-sm-6 col-md-4 col-lg-3 mb-4",
          data.id
        );
  const d1 =
    currentListMode === MovieLayoutMode.Grid
      ? createElem("div", "card")
      : createElem("div", "card-list");
  film.appendChild(d1);
  const d2 = createElem("div", "row g-0");
  d1.appendChild(d2);
  const d3 = createElem("div", "col-12");
  d2.appendChild(d3);
  const poster = createPoster("poster", data.poster);
  d3.appendChild(poster);
  const d4 = createElem("div", "col-12");
  d2.appendChild(d4);
  const d5 = createElem("div", "car-body");
  d4.appendChild(d5);
  const title = createTitle("h5", "card-title my-3 mx-3", data.title);
  d5.appendChild(title);
  const ratingAndYear = createRatingAndYear(
    "span",
    "my-3 mx-3",
    data.rating,
    data.year
  );
  d5.appendChild(ratingAndYear);
  const description = createDescription(
    "p",
    "card-text my-3 mx-3",
    data.description
  );
  d5.appendChild(description);
  return film;
}

function createMovies(movieListData: MovieListData[]): HTMLElement {
  const moviesElement = document.createElement("div");
  moviesElement.className = "row";
  currentListMode === MovieLayoutMode.Grid ? console.log("grid"): console.log("list");
  movieListData.forEach((data) => {
    if (data.id !== -1) {
      const film = createFilm(data);
      moviesElement.appendChild(film);
    }
  });
  return moviesElement;
}

function editPagesNav(page: number, pages: number) {
  const p = document.getElementById("page");
  if (p !== null) {
    p.textContent = page + " / " + pages;
  }
} 