import { MovieLayoutMode } from "../models/movie-layout-mode.enum";
import { MovieListData } from "../models/movie-list-data.interface";
import { MovieListType } from "../models/movie-type.enum";
import {
  fetchMovieListData,
  fetchSearchMovieListData,
  getDetailsData,
} from "../api/api";
import { MovieDetail } from "../models/movie-detail.interface";
import { addEventListenerMovieCard } from "../event/event";
import { Actor } from "../models/actor.interface";
import { Director } from "../models/director.interface";

let currentListType = MovieListType.NowPlaying;
let currentListMode = MovieLayoutMode.Grid;
let currentMovieListData: MovieListData[];
let total_pages: number = 0;
let currPage: number = 1;
export let search: boolean = false;
export let currSearch: string = "";
let currSearchPage: number = 1;

export async function updateMoviesContent(page: number = currPage) {
  const data = await fetchMovieListData(currentListType, page);
  currentMovieListData = data.movies;
  currPage = page;
  total_pages = data.total_pages;
  showMovieList(currentMovieListData, currPage, total_pages);
}

export async function updateMovieDetailsContent(id: string) {
  const data = await getDetailsData(id);
  createDetails(data);
  // showMovieList(currentMovieListData);
}

export async function searchMovie(text: string, page: number = 1) {
  search = true;
  currSearch = text;
  const data = await fetchSearchMovieListData(text, currSearchPage);
  currentMovieListData = data.movies;
  total_pages = data.total_pages;
  currSearchPage = page;
  showMovieList(currentMovieListData, currSearchPage, total_pages);
}

export async function setCurrentListType(newValue: MovieListType) {
  currentListType = newValue;
  // fetch de nuevo listado de películas
  search = false;
  currSearch = "";
  const data = await fetchMovieListData(currentListType);
  currentMovieListData = data.movies;
  total_pages = data.total_pages;
  currPage = 1;
  showMovieList(currentMovieListData, currPage, total_pages);
}

export function setCurrentListMode(newValue: MovieLayoutMode) {
  currentListMode = newValue;
  showMovieList(currentMovieListData, currPage, total_pages);
}

export function showMovieList(movieListData: MovieListData[], page: number, pages: number) {
  const movieListElement = createMovies(movieListData);
  const app = document.querySelector("#app");
  if (app !== null) {
    app.innerHTML = "";
    app.appendChild(movieListElement);
    editPagesNav(page, pages);
  }
}

function createElem(elem: string, className: string): HTMLElement {
  const e = document.createElement(elem);
  e.className = className;
  return e;
}

function createBackdrop(
  elem: string,
  className: string,
  url: string
): HTMLElement {
  const e = createElem(elem, className);
  e.setAttribute("style", `background-image: url(${url});`);
  return e;
}

function createDetailRatingAndYear(
  elem: string,
  className: string,
  rating: number,
  year: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = "Valoración: " + rating + " | Año: " + year;
  return e;
}

function createSynopsis(
  elem: string,
  className: string,
  description: string
): HTMLElement {
  const e = createElem(elem, className);
  e.innerHTML = "<h6>Sinopsis:</h6>" + description;
  return e;
}

function createActorCard(actor: Actor): HTMLElement {
  const card = createElem("div", "card actor");
  const poster = createPoster("poster", actor.path);
  card.appendChild(poster);
  const name = createElem("span", "");
  name.textContent = "Nombre: " + actor.name;
  card.appendChild(name);
  const character = createElem("span", "");
  character.textContent = "Personaje: " + actor.character;
  card.appendChild(character);
  return card;
}

function actors(actors: Actor[]): HTMLElement {
  const arr: HTMLElement[] = actors.map(createActorCard);
  const row = createElem("div", "w-25 row d-flex justify-content-between");
  arr.forEach((actor) => row.appendChild(actor));
  return row;
}

function createDirectorCard(director: Director){
  const card = createElem("div", "w-25 card");
  const poster = createPoster("poster", director.path);
  card.appendChild(poster);
  const name = createElem("span", "");
  name.textContent = "Director: " + director.name;
  card.appendChild(name);
  return card;
}

function getGenres(genres: string[]): string{
  let res = "";
  let i = 0;
  if (i < genres.length) {
    res = genres[i];
    i++;
    while (i < genres.length) {
      res += ", " + genres[i];
      i++;
    }
  }
  return res;
}

function createDetails(data: MovieDetail) {
  const app = document.querySelector("#app");
  if (app !== null) {
    app.innerHTML = "";

    const header = createArticle(
      "article",
      "content list col-12 col-sm-6 col-md-4 col-lg-3 mb-4",
      data.id
    );


    const d1 = createElem("div", "card-list");
    const d2 = createElem("div", "row g-0");
    d1.appendChild(d2);
    const d3 = createElem("div", "col-12");
    d2.appendChild(d3);
    const poster = createPoster("poster mw-220", data.poster);
    d3.appendChild(poster);
    const d4 = createElem("div", "col-12");
    d2.appendChild(d4);


    const d5 = createElem("div", "car-body");
    const title = createTitle("h5", "card-title my-3 mx-3", data.title);
    d5.appendChild(title);
    const genres = createElem("p", "my-3 mx-3");
    genres.textContent = getGenres(data.genres);
    d5.appendChild(genres);
    const duration = createElem("p", "my-3 mx-3");
    duration.textContent = "Duración: " + data.duration + " minutos";
    d5.appendChild(duration);
    const ratingAndYear = createDetailRatingAndYear(
      "p",
      "my-3 mx-3",
      data.rating,
      data.year
    );
    d5.appendChild(ratingAndYear);
    const description = createSynopsis(
      "p",
      "card-text my-3 mx-3",
      data.synopsis
    );
    d5.appendChild(description);
    d4.appendChild(d5);
    
    header.appendChild(d1);
    const details = createBackdrop("div", "row backdrop", data.backdrop);
    const opacity = createElem("div", "opacity");
    details.appendChild(opacity);
    opacity.appendChild(header);
    app.appendChild(details);
    
    
    const dir = createDirectorCard({name: data.director, path: data.director_path});
    app.appendChild(dir);
    const da = createElem("div", "row");
    const d6 = actors(data.actors);
    da.appendChild(d6);
    app.appendChild(da);
  }
}

function createArticle(
  elem: string,
  className: string,
  id: number
): HTMLElement {
  const e = createElem(elem, className);
  e.id = `${id}`;
  addEventListenerMovieCard(e);
  return e;
}

function createPoster(className: string, url: string): HTMLImageElement {
  const e = document.createElement("img");
  e.className = className;
  e.src = url;
  return e;
}

function createTitle(
  elem: string,
  className: string,
  title: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = title;
  return e;
}

function createRatingAndYear(
  elem: string,
  className: string,
  rating: number,
  year: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = "Rating: " + rating + " | " + year;
  return e;
}

function createDescription(
  elem: string,
  className: string,
  description: string
): HTMLElement {
  const e = createElem(elem, className);
  e.textContent = description;
  return e;
}

function createFilm(data: MovieListData): HTMLElement {
  const film =
    currentListMode === MovieLayoutMode.Grid
      ? createArticle(
          "article",
          "col-12 col-sm-6 col-md-4 col-lg-3 mb-4",
          data.id
        )
      : createArticle(
          "article",
          "list col-12 col-sm-6 col-md-4 col-lg-3 mb-4",
          data.id
        );
  const d1 =
    currentListMode === MovieLayoutMode.Grid
      ? createElem("div", "card")
      : createElem("div", "card-list");
  film.appendChild(d1);
  const d2 = createElem("div", "row g-0");
  d1.appendChild(d2);
  const d3 = createElem("div", "col-12");
  d2.appendChild(d3);
  const poster = createPoster("poster", data.poster);
  d3.appendChild(poster);
  const d4 = createElem("div", "col-12");
  d2.appendChild(d4);
  const d5 = createElem("div", "car-body");
  d4.appendChild(d5);
  const title = createTitle("h5", "card-title my-3 mx-3", data.title);
  d5.appendChild(title);
  const ratingAndYear = createRatingAndYear(
    "span",
    "my-3 mx-3",
    data.rating,
    data.year
  );
  d5.appendChild(ratingAndYear);
  const description = createDescription(
    "p",
    "card-text my-3 mx-3",
    data.description
  );
  d5.appendChild(description);
  return film;
}

function createMovies(movieListData: MovieListData[]): HTMLElement {
  const moviesElement = document.createElement("div");
  moviesElement.className = "row";
  currentListMode === MovieLayoutMode.Grid
    ? console.log("grid")
    : console.log("list");
  movieListData.forEach((data) => {
    if (data.id !== -1) {
      const film = createFilm(data);
      moviesElement.appendChild(film);
    }
  });
  return moviesElement;
}

function editPagesNav(page: number, pages: number) {
  const p = document.getElementById("page");
  if (p !== null) {
    p.textContent = page + " / " + pages;
  }
}
