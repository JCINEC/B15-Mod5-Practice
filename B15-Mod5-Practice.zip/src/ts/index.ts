import "../scss/styles.scss";

import { addEventListenerMovieListType, addEventListenerMovieGridButton, addEventListenerMovieListButton, addEventListenerClickSearch, addEventListenerClickBack, addEventListenerClickBackPage, addEventListenerClickForwardPage } from "./event/event";
import { updateMoviesContent } from "./movie/movie"

addEventListenerMovieListType();
addEventListenerMovieGridButton();
addEventListenerMovieListButton();
addEventListenerClickSearch();
addEventListenerClickBack();
addEventListenerClickBackPage();
addEventListenerClickForwardPage();

updateMoviesContent();




