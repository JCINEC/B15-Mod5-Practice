export interface ApiConfig {
    baseUrl: string,
    langIso: string,
    apiKey: string,
}