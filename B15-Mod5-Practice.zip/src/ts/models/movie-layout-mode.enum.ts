export enum MovieLayoutMode {
    Grid,
    List,
}