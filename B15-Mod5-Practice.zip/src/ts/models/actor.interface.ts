export interface Actor {
    name: string;
    path: string;
    character: string; 
}