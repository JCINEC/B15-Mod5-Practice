export interface MovieListData {
    id: number;
    title: string;
    description: string;
    year: string;
    rating: number;
    poster: string;
}