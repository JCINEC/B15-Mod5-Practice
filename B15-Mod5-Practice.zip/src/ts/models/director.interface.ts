export interface Director {
    name: string;
    path: string;
}