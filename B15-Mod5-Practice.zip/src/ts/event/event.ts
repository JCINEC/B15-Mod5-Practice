import { MovieListType } from "../models/movie-type.enum";
import { searchMovie, setCurrentListMode, setCurrentListType, updateMovieDetailsContent, updateMoviesContent, currSearch, search } from "../movie/movie";
import { MovieLayoutMode } from "../models/movie-layout-mode.enum";

export function addEventListenerMovieListType(){
    const elem: HTMLElement | null = document.getElementById("movie-type-select");
    
    if(elem === null) throw new Error('The "movie-type-select" id does not exist.');

    elem.addEventListener("change", (event: Event) => {
        const selectElement = event.target as HTMLSelectElement;
        setCurrentListType(selectElement.value as MovieListType);
    });
}
/*Prueba*/
function searchListener(event) {
    event.preventDefault();
    const text = document.getElementById("search-input") as HTMLInputElement;
    if (text.value?.length && text.value.length > 0){
        searchMovie(text.value);
    }
}

export function addEventListenerClickSearch() {
    const button = document.getElementById("search-button");
    button?.addEventListener('click', searchListener);
    /*'https://api.themoviedb.org/3/search/keyword?page=1'*/
}

function back(event){
    event.preventDefault();
    document.getElementById("detail")?.setAttribute("hidden", "true");
    document.getElementById("movies")?.removeAttribute("hidden");
    document.getElementById("pages")?.removeAttribute("hidden");
    /*Poner código de listado o grid de películas*/
    (!search) ? updateMoviesContent(): searchMovie(currSearch, getPage());
}

export function addEventListenerClickBack() {
    const button = document.getElementById("btn-back");
    button?.addEventListener('click', back);
    /*'https://api.themoviedb.org/3/search/keyword?page=1'*/
}

function getPage():number {
    return Number(document.getElementById("page")?.textContent?.split(" / ")[0]);
}

function getTotalPages():number {
    return Number(document.getElementById("page")?.textContent?.split(" / ")[1]);
}

function backPage(){
    const prevPage : number = getPage() - 1;
    if (prevPage >= 1) {
        (currSearch === "") ? updateMoviesContent(prevPage): searchMovie(currSearch, prevPage);
    }
}

function forwardPage(){
    const nextPage : number = getPage() + 1;
    const pages : number = getTotalPages();
    if (nextPage <= pages) {
        (search) ?  searchMovie(currSearch, nextPage): updateMoviesContent(nextPage);
    }
}

export function addEventListenerClickBackPage() {
    const button = document.getElementById("btn-back-page");
    button?.addEventListener('click', backPage);
}

export function addEventListenerClickForwardPage() {
    const button = document.getElementById("btn-forward-page");
    button?.addEventListener('click', forwardPage);
}

export function addEventListenerMovieGridButton() {
    const elem: HTMLElement | null = document.getElementById("btn-grid-mode");

    if(elem == null) throw new Error('The "btn-grid-mode" id does not exist.');

    elem.addEventListener("click", (event: Event) => {
        setCurrentListMode(MovieLayoutMode.Grid)
    });
}

export function addEventListenerMovieListButton() {
    const elem: HTMLElement | null = document.getElementById("btn-list-mode");

    if(elem == null) throw new Error('The "btn-list-mode" id does not exist.');

    elem.addEventListener("click", (event: Event) => {
        setCurrentListMode(MovieLayoutMode.List)
    });
}

export function addEventListenerMovieCard(card: HTMLElement) {
    card.addEventListener('click', () => {
        document.getElementById("movies")?.setAttribute("hidden", "true");
        document.getElementById("detail")?.removeAttribute("hidden");
        document.getElementById("pages")?.setAttribute("hidden", "true");
        updateMovieDetailsContent(card.id);
    });
}