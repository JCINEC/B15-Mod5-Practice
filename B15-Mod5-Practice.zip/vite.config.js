export default {
  root: "src",
  publicDir: "../public",
  build: {
    outDir: "../dist",
  },
};
